<?php
require_once'../../config.php';
#admin用
#require_capability('local/helloworld:view', context_system::instance());

#phpseclib
#include_once('/var/www/html/vendor-downloads/phpseclib/autoload.php');
include_once('../../vendor-downloads/phpseclib/autoload.php');


global $USER, $DB, $CFG, $file;

#PrivateFileArea用
#require_once("/var/www/html/user/files_form.php");
require_once("../../user/files_form.php");
#require_once("/var/www/html/repository/lib.php");
require_once("../../repository/lib.php");

#試し
#require_capability('local/helloworld:view', context_system::instance());

#$context = context_user::instance($USER->id);
$context = context_user::instance($USER->id);
#ここまで

$PAGE->set_url('/local/helloworld/index.php');
#$PAGE->set_context(context_system::instance());
$PAGE->set_context($context);
$PAGE->requires->js('/local/helloworld/assets/helloworld.js');

#試し
$homeurl = new moodle_url('/');
require_login();
#試し
if (!is_siteadmin()) {
    redirect($homeurl, "This feature is only available for site administrators.", 5);
}

#urlから情報を入手
$ipaddress = optional_param('ipaddress','',PARAM_TEXT);
#PARAM_HOST(var/www/html/lib/moodlelib)
$userid = optional_param('userid','',PARAM_TEXT);
$path = optional_param('path','',PARAM_TEXT);
$password = optional_param('password','',PARAM_TEXT);

#PrivateAreaFile用
$returnurl = optional_param('returnurl', '', PARAM_LOCALURL);
if (empty($returnurl)) {
    $returnurl = new moodle_url('/local/helloworld/index.php');
}
$maxareabytes = $CFG->userquota;
$maxbytes = $CFG->userquota;
#$maxareabytes = FILE_AREA_MAX_BYTES_UNLIMITED;
$data = new stdClass();
$data->returnurl = $returnurl;
$options = array('subdirs' => 1, 'maxbytes' => $maxbytes, 'maxfiles' => -1, 'accepted_types' => '*', 'areamaxbytes' => $maxareabytes);
file_prepare_standard_filemanager($data, 'files', $options, $context, 'user', 'private', 0);
#ここまで

#変数objにstring型で値を入れる
$obj = new stdClass();
$obj->ipaddress = (string)$ipaddress;
$obj->userid = (string)$userid;
$obj->path = (string)$path;
$obj->password = (string)$password;

// ここからphpseclib 簡易autoloader
$phpseclibpath = "/root/.composer/cache/files/phpseclib/phpseclib/phpseclib-phpseclib-2f0b7af/phpseclib";
set_include_path(get_include_path() . PATH_SEPARATOR . $phpseclibpath);
spl_autoload_register(function($class){
	if (strpos($class, "phpseclib") === 0) {
		$class = str_replace("\\", "/", $class);
	    	include $class . ".php";
	}
});

use phpseclib3\Net\SSH2;
use phpseclib3\Net\SFTP;
use phpseclib3\Crypt\PublicKeyLoader;

// ログイン情報
$host = $ipaddress;
$port = "22";
$username = $userid;
$filename = "grades" . date('Y-m-d') . ".csv";
#レコード処理用
$checkvalue = 0;

if(isset($ipaddress,$userid,$path,$password)){
	try {
		$ssh = new SSH2($ipaddress);
		if (!$ssh->login($userid,$password)) {
			throw new Exception("ログインできませんでした。");
		}

		echo "～～～～～ START ～～～～～\r\n";

		// ログイン成功時のコンソール内容を読み込む。
		echo $ssh->read('/\[(root|' . $username . ')@.*\ .*][#$]/', SSH2::READ_REGEX);

		$ssh->write("cd " . $path . "\n");
		echo $ssh->read('/\[(root|' . $username . ')@.*\ .*][#$]/', SSH2::READ_REGEX);

		$ssh->write("nbgrader export --to " . $filename . " \n");
		echo $ssh->read('/\[(root|' . $username . ')@.*\ .*][#$]/', SSH2::READ_REGEX);

		$ssh->write("exit");
		echo $ssh->read('/\[(root|' . $username . ')@.*\ .*][#$]/', SSH2::READ_REGEX);

		echo "\r\n";
		echo "～～～～～ END ～～～～～\r\n";

		// ファイルをダウンロードする。
		$sftp = new SFTP($ipaddress);
		if (!$sftp->login($userid,$password)) {
			throw new Exception("ログインできませんでした。");
		}

		echo "～～～～～ START ～～～～～\r\n";

		#echo $sftp->get($path . "/" . $filename . " \n" ,"/var/www/html/local/helloworld/DownloadFile/" . $filename . " \n");
		echo $sftp->get($path . "/" . $filename,"DownloadFile/$filename");
		echo $sftp->read('/\[(root|' . $username . ')@.*\ .*][#$]/', SSH2::READ_REGEX);

		echo "\r\n";
		#処理ができた時にレコード追加処理を行う
		$checkvalue = 1;
		echo "～～～～～ END ～～～～～\r\n";

	}catch (Exception $e) {
		echo "エラー発生\r\n";
		echo $e->getMessage() . "\r\n";
	}
}

$strpagetitle = get_string('plugintitle','local_helloworld');
$strpageheading = get_string('plugintitle','local_helloworld');

$PAGE->set_title($strpagetitle);
$PAGE->set_heading($strpageheading);

echo $OUTPUT->header();

#画面のレンダリング+変数obj（URLから入手した値を入れている）を代入している
echo $OUTPUT->render_from_template('local_helloworld/searchbar3',$obj);

#PrivateFileAreaの追加
$generator = new \core\message\inbound\address_manager();
$generator->set_handler('\core\message\inbound\private_files_handler');
$generator->set_data(-1);
$data->emaillink = $generator->generate($USER->id);

$mform = new user_files_form(null, array('data' => $data, 'options' => $options));

if ($mform->is_cancelled()) {
    redirect($returnurl);
} else if ($formdata = $mform->get_data()) {
    $formdata = file_postupdate_standard_filemanager($formdata, 'files', $options, $context, 'user', 'private', 0);
    redirect($returnurl);
}

echo $OUTPUT->box_start('generalbox');

if ($maxareabytes != FILE_AREA_MAX_BYTES_UNLIMITED) {
    $fileareainfo = file_get_file_area_info($context->id, 'user', 'private');
    // Display message only if we have files.
    if ($fileareainfo['filecount']) {
        $a = (object) [
            'used' => display_size($fileareainfo['filesize_without_references']),
            'total' => display_size($maxareabytes)
        ];
        $quotamsg = get_string('quotausage', 'moodle', $a);
        $notification = new \core\output\notification($quotamsg, \core\output\notification::NOTIFY_INFO);
        echo $OUTPUT->render($notification);
    }
}

$mform->display();
echo $OUTPUT->box_end();
#ここまで

#ファイルをプライベートファイルに入れる処理

if(isset($ipaddress,$userid,$password,$path) && $checkvalue == 1){
    #最初の処理
    $component  = 'user';
    $filearea   = 'private';
    $itemid     = 0;
    $license    = $CFG->sitedefaultlicense;
    $author     = fullname($USER);
    $attachment   = $filename;

    #maxbytes処理に関してはprivatefileareaを作るときに定義している

    $fs = get_file_storage();

    #このファイルに対する新しいレコードを作成
    $record = new \stdClass();
    $record->filearea   = $filearea;
    $record->component  = $component;
    $record->filepath   = '/';
    $record->itemid     = $itemid;
    $record->license    = $license;
    $record->author     = $author;
    $record->contextid  = $context->id;
    $record->userid     = $USER->id;
    
    $record->filename = $fs->get_unused_filename($context->id, $record->component, $record->filearea, $record->itemid, $record->filepath, $attachment);
    #print_r($record);#確認
    
    mtrace("--> Attaching {$record->filename} to " . "/{$record->contextid}/{$record->component}/{$record->filearea}/" . "{$record->itemid}{$record->filepath}{$record->filename}");
    
    #文字列からファイルを作成
    $s = exec('pwd');
    echo $s;
    #if ($fs->create_file_from_string($record, file_get_contents("/var/www/html/local/helloworld/DownloadFile/" . $attachment))) {
    if ($fs->create_file_from_string($record, file_get_contents("DownloadFile/" . $attachment))) {
        mtrace("---- File uploaded successfully as {$record->filename}.");
    	#exec('rm /var/www/html/local/helloworld/DownloadFile/' . $filename);
    	exec('rm DownloadFile/' . $filename);
    } else {
	mtrace("---- Skipping attachment. Unknown failure during creation.");
	#exec('rm /var/www/html/local/helloworld/DownloadFile/' . $filename);
	exec('rm DownloadFile/' . $filename);
    }
    $checkvalue = 0;
}
$checkvalue = 0;
$ipaddress = null;
$userid = null;
$path = null;
$password = null;
#ここまで
#一回ダウンロードした成績ファイルを削除
//exec('rm /var/www/html/local/helloworold/DownloadFile/' . $filename);

echo $OUTPUT->footer();
