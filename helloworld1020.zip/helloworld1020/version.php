<?php

$plugin->component = 'local_helloworld';
$plugin->version = 2022060603;
