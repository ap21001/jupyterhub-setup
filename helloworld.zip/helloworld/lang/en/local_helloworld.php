<?php

$string['pluginname'] = 'Hello world';
$string['plugintitle'] = 'Moodleへの成績ファイルの保存';
$string['helloworld:view'] = 'Able to view index.php';
