require(['core/first', 'jquery', 'jqueryui', 'core/ajax'], function(core, $, bootstrap, ajax) {


  $(document).ready(function() {

/*    var params = {};
    window.location.search
      .replace(/[?&]+([^=&]+)=([^&]*)/gi, function(str, key, value) {
        params[key] = value;
      });

    // set default value for dropdowns
    if (params['assignment']) {
      $('#assignment option[value=' + params['assignment'] + ']').attr('selected', 'selected');
    }
*/
    $('#input').click(function() {
      inputassighment();
    });

    $('#download').click(function(){
      var data = {
	//download : $('#download').val()
	download : 1
      };
      $.ajax({
        type:"post",
	url: "index.php",
	data: data,
	success: function(data, dataType){
           alert("成功");
	},
	error: function(){
           alert("失敗");
	}       
      });
	return false;
    });

    function inputassighment() {
      console.log('input assignment');
      window.open("/local/helloworld/index.php?ipaddress=" + $('#ipaddress').val() + "&userid=" + $('#userid').val() + "&password=" + $('#password').val() + "&path=" + $('#path').val(), '_self');
    }
  });
});
